# 更新记录 / Changelog

## 0.2.0 本地预览（未发布） / Local preview (unpublished)

- 为图片 JSONL 通道记录固定流原因、解析阶段、帧序号/字节数、init/result 计数、最近帧类别，以及终止发起方、是否观察到 close 和是否到达总时限。各拒绝路径仍保持原有协议边界；不记录帧正文或任意字段值。
- 为原生响应记录 `structured_output` 是否存在及固定类型、result 类型是否符合要求、终态 subtype 类别，以及固定 CLI 提示分类和来源。普通日志仅保存白名单字段；持久化、恢复和导出均经过过滤。
- 图片调用超时时使用中性总时限提示，不推断登录、网络或额度原因。未知 JSONL 序列继续拒绝，不做修复、回退、重试或选取最后结果。
- 配置页和本机日志分别统计用户取消、DSH 图片卸载请求次数及请求卸载张数，也统计请求历史中已经标记卸载的图片。卸载请求仅表示插件向 DSH 报告所需数量，不证明 DSH 已完成卸载。未观察到的退出码不会补造。
- 43 项定向自动检查通过，覆盖合成 JSONL、自然关闭时的坏尾帧、原生结果诊断、隐私白名单、取消/卸载计数及直接受影响的账号/图片/配置页回归。均为本地合成夹具；未发起真实 CLI 模型请求、未测试实际 DSH UI 或业务工具，也未重放用户原始会话。本地候选不代表复现了用户原始偶发故障。

## 0.2.0 local preview (unpublished) — English

- Add fixed diagnostics for image JSONL reason, parse stage, frame index/byte length, init/result counts, last-frame class, termination initiator, observed close and deadline state. Existing protocol refusals remain in place; frame bodies and arbitrary field values are not logged.
- Record whether native `structured_output` exists and its fixed type, whether the result type is accepted, a bounded terminal-subtype class, and fixed CLI notice class/source. Basic logs use a field allowlist through persistence, recovery and export.
- Image-call timeouts use a neutral total-deadline message without inferring sign-in, network or credit causes. Unknown JSONL sequences still fail closed; no repair, fallback, retry or last-result selection is added.
- Settings and local logs separately count user cancellations, DSH image-offload requests and requested image counts, as well as images already marked offloaded in request history. An offload request does not prove that DSH completed it. Unobserved exit codes are never fabricated.
- All 43 targeted automated checks pass, covering synthetic JSONL, malformed tails during natural close, native-result diagnostics, privacy allowlists, cancellation/offload counters and directly affected account/image/settings regressions. These use local synthetic fixtures; no live CLI model request, actual DSH UI/business tool or private-session replay was performed. This preview does not reproduce the users’ original intermittent failures.

## 0.1.9 本地预览（未发布） / Local preview (unpublished)

- 新增 Windows 独立账号环境：每个环境隔离官方 CLI 配置目录及 HOME、USERPROFILE、LOCALAPPDATA、APPDATA 等用户目录变量；用户通过生成的 PowerShell 命令手动完成 International Site 登录。
- DSH 模型 ID 固定绑定环境，工具和图片续轮沿用原账号；移除、登录文件缺失、目录/列表损坏和并发锁异常均明确失败，不轮换、不回退默认账号。移出列表不会注销或删除官方登录文件。
- 独立账号仅支持经核查的官方 npm/Node CLI 2.174.0 和 Windows。未登录第二账号、未发起模型请求，未验证令牌刷新或官方扣费归属；配置页本地统计不等同于官方账单。
- 增加 400 上下文超限与 402 余额不足固定分类；内联图片 data URI 增加 32,768 字符合计限制，诊断不保留 URI 内容。
- 96 项自动检查通过，包含账号环境绑定、工具/图片续轮、登录命令脚本准备、版本守卫、敏感凭据隔离及既有图片/结构化输出回归。

## 0.1.9 local preview (unpublished) — English

- Add isolated Windows account environments. Each one separates the official CLI config directory and HOME, USERPROFILE, LOCALAPPDATA, APPDATA and related user-directory variables. The user completes International Site sign-in manually through a generated PowerShell command.
- DSH model IDs stay bound to their environment, including tool and image follow-ups. Removal, missing sign-in files, invalid directories/lists and lock conflicts fail explicitly; there is no rotation or default-account fallback. Removing a list entry does not sign out or delete official login files.
- Isolated accounts are limited to Windows and the verified official npm/Node CLI 2.174.0. No second account was signed in and no model request was made; token refresh and official billing attribution remain unverified. Local counters are not official billing.
- Add fixed 400 context-limit and 402 insufficient-balance classifications. Inline image data URIs have a 32,768-character aggregate limit, and diagnostics do not retain URI content.
- All 96 automated checks pass, covering account binding, tool/image follow-ups, generated sign-in script preparation, version guard, credential isolation and existing image/structured-output regressions.

## [0.1.8](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.8)

- 增加 `CLI_NETWORK_ERROR` 固定分类：仅当无有效结果且官方 CLI 错误文本符合已知 ECONNRESET、TLS 连接中断或相关 502 模式时命中；鉴权与本地权限分类优先，未知错误仍保留原通用分类。
- 使用固定安全提示，不暴露 stderr、URL 或凭据；不添加 HTTP 状态或重试标志，不自动重试，也不改动网络、代理、登录或用户配置。图片 JSONL error 帧和空流通过同一分类器处理。
- 配置页与中英故障指南说明分类只帮助诊断，不能修复网络或证明具体根因；请先核对已完成的 DSH 操作，再自行决定是否重试。
- 83 项合成自动检查通过，含分类边界、未知示例不误判、有效结果不受 stderr 旧提示影响、适配器无重试与图片 error 帧覆盖。本版没有真实模型请求或用户手动故障注入，不能声称复现了真实网络故障或恢复网络。

## [0.1.8](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.8) — English

- Add the fixed `CLI_NETWORK_ERROR` classification only when no valid result is available and CLI error text matches a known ECONNRESET, TLS disconnect or related 502 pattern. Authentication and local-permission classifications retain precedence; unknown errors keep their generic classification.
- Return a fixed safe message without exposing stderr, URLs or credentials. Add no HTTP status or retry flag, make no automatic retry, and change no network, proxy, sign-in or user settings. Image JSONL error frames and empty streams use the same classifier.
- The settings page and bilingual guide clarify that this classification aids diagnosis but cannot repair connectivity or prove a specific root cause. Check completed DSH actions before deciding whether to retry.
- All 83 synthetic automated checks pass, including classification boundaries, quoted/unknown examples, valid results with stale stderr, no adapter retry and image error-frame coverage. No live model call or manual fault injection was performed; this does not claim to reproduce or restore a real network failure.

## [0.1.7](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.7)

- 支持读取任意 DSH 工具标准 tool 结果中的图片附件：消息必须带非空 toolCallId，图片必须是 DSH content 中的标准 attachment 引用。没有工具名白名单；只要工具按此格式返回即可，不代表所有第三方工具都已逐个实测。
- 用户图片与工具结果图片沿用同一附件读取、图片预算、DSH 卸载和日志隐私处理；保留 toolCallId、isError、内容顺序。assistant、system、developer 图片继续拒绝；工具图片缺少 toolCallId 时明确报 IMAGE_TOOL_CALL_INVALID。
- 不读取任意本地路径、URL 或裸 Base64；不适配原生音视频、PDF 内容解析、图片生成及工具自定义的非标准截图输出。CLI 仍只开放 StructuredOutput，业务工具仍由 DSH 执行。
- 图片 JSONL 通道现可安全识别 CLI error 帧的字符串或 message 字段：已知鉴权/本地权限错误归为固定错误码，未知错误使用 CLI_REQUEST_FAILED；错误帧后续即使出现 result 也不会交付。
- 80 项合成自动检查通过，覆盖用户与工具图片混排、工具单独截图、工具 ID/isError/顺序、共用预算、卸载、日志隐私及 error 帧分类。没有发起新模型请求；未逐个验证实际 DSH 桌面/浏览器/第三方截图工具或上传界面。
- 沿用 0.1.5 的历史实际适配器结果：deepseek-v4.1-flash 文字与合成六色图片通过；gpt-5.6-luna 文字对照为 CLI_OUTPUT_INVALID，未发送图片。这不是对所有模型或实际 DSH 截图工具的验证。

## [0.1.7](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.7) — English

- Accept image attachments in standard DSH tool-result messages from any tool name, provided the message has a non-empty toolCallId and the image uses the standard DSH content attachment reference. There is no tool-name allowlist; this does not mean every third-party tool has been individually tested.
- User and tool-result images share attachment reading, image budgets, DSH offloading and log privacy handling. Preserve toolCallId, isError and content order. Images in assistant, system and developer messages remain unsupported; a tool image without toolCallId fails with IMAGE_TOOL_CALL_INVALID.
- Do not read arbitrary local paths, URLs or raw Base64. Native audio/video, PDF content extraction, image generation and non-standard tool screenshot output are not adapted. StructuredOutput remains the only enabled CLI tool; DSH executes business tools.
- The image JSONL route safely handles CLI error frames with either a string or message field. Known authentication/local-permission errors use fixed classifications; unknown errors use CLI_REQUEST_FAILED. No later result is delivered after an error frame.
- All 80 synthetic automated checks pass, covering mixed user/tool images, tool-only screenshots, tool ID/isError/order, shared budgets, offloading, log privacy and error-frame classification. No new model request was made. Actual DSH desktop/browser/third-party screenshot tools and the upload UI were not individually verified.
- Inherited 0.1.5 adapter evidence: deepseek-v4.1-flash text and a synthetic six-color image passed; the gpt-5.6-luna text control returned CLI_OUTPUT_INVALID and no image was sent. This does not validate every model or actual DSH screenshot tool.

## [0.1.6](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.6)

- 修复 DSH 0.2.1-rc.3 对国际版旧版精确 rc.2 依赖的兼容性拦截。engines.dsh 与六项 DSH peer 依赖均明确声明 0.2.1-rc.2 || 0.2.1-rc.3；其他 DSH 版本未声明兼容。
- 本版仅更新插件版本、兼容元数据与说明文档，没有改变业务实现。77 项合成自动检查通过；按官方 DSH 兼容检查逻辑验证 rc.2、rc.3 均满足 engines 和六项 peer 声明。
- 沿用 0.1.5 已有验证：deepseek-v4.1-flash 的国际 CLI 文字与合成六色图片经实际适配器调用通过；gpt-5.6-luna 文字对照仍返回 CLI_OUTPUT_INVALID，未发送图片。未验证所有模型或真实 DSH 上传界面；本版没有发起新的模型调用。

## [0.1.6](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.6) — English

- Fix DSH 0.2.1-rc.3 rejecting the previous exact rc.2 requirements for the International plugin. engines.dsh and all six DSH peer dependencies now declare exactly 0.2.1-rc.2 || 0.2.1-rc.3; compatibility with other DSH versions is not claimed.
- This release changes only the plugin version, compatibility metadata and documentation. All 77 synthetic automated checks pass; the official DSH compatibility logic accepts rc.2 and rc.3 for both the engine and all six peer declarations.
- Inherited 0.1.5 validation: actual International CLI adapter text and a synthetic six-color image passed with deepseek-v4.1-flash. The gpt-5.6-luna text control still returned CLI_OUTPUT_INVALID, and no image was sent. Not all models or the actual DSH upload UI were verified. No new model request was made for this release.

## [0.1.5](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.5)

- 新增模型图片输入能力：仅在 CLI 动态目录明确标记 `supportsImages` 时展示和允许图片输入；本机 DSH 附件通过 `ctx.attachments.readImageRequest` 转换为官方 CLI 原生 stream-json 图片块。
- 为每次请求设置 5 张保留图片、每张 2 MiB、Base64 总量 8 MiB 和 1920 像素最长边目标。已由 DSH 卸载的旧图不重读；格式、读取、取消和预算错误均会明确失败，不发送部分图片。
- 图片请求仍只启用官方 `StructuredOutput`，不开放 CLI 文件或命令工具；工具计划交给 DSH 执行。文本请求保留原 JSON 输出路线。
- 配置页增加模型图片能力状态与双语限制说明。图片内容、Base64 和附件 ID 不进入诊断日志。
- 77 项合成自动检查通过，覆盖 CLI JSONL 终止与冲突、目录能力、图片顺序与预算、工具续接和日志隐私。使用既有国际 CLI 配置运行纯文本原生 Schema 对照时，`gpt-5.6-luna` 和 `deepseek-v4.1-flash` 均返回 `CLI_AUTH_REQUIRED`（401）；因此没有发送图片请求，国际站真实识图尚未验证。
- 此前因相对路径指向错误配置目录而产生的超时，以及一次未检查错误状态和识图内容的裸 CLI 图片结果，均不作为本版验证证据；国内版结果也不能替代国际版验证。自动测试使用合成附件和假 CLI，不产生真实模型调用。实现组合采用官方 CLI 文档描述的原生 stream-json 图片输入与 JSON Schema 结构化输出格式，官方文档分开描述这两种模式。真实调用仍要求有效的国际 CLI 登录和所选模型权限；本版未验证所有模型或 DSH 界面上传流程。

## [0.1.5](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.5) — English

- Add model image input, enabled only when the CLI's live catalog explicitly marks `supportsImages`. DSH attachments are projected through `ctx.attachments.readImageRequest` into native CLI stream-json image blocks.
- Bound each request to 5 retained images, 2 MiB per image, 8 MiB aggregate Base64 and a 1920-pixel target longest edge. DSH-offloaded history is not reread; format, read, cancellation and budget failures are explicit and never send partial images.
- Image requests still enable only official `StructuredOutput`; CLI file and command tools stay disabled, and DSH executes tool plans. Text requests keep the existing JSON output route.
- Add model image-capability status and bilingual limits to settings. Image content, Base64 and attachment IDs are excluded from diagnostics.
- All 77 synthetic automated checks pass, covering JSONL terminal/conflict handling, catalog capability, image order and budgets, DSH tool continuation and log privacy. Text-only native Schema controls using the existing International CLI profile returned `CLI_AUTH_REQUIRED` (401) on both `gpt-5.6-luna` and `deepseek-v4.1-flash`; no image request was sent, so live International image recognition remains unverified.
- Earlier timeouts resulted from a relative path resolving to the wrong profile, and an earlier bare CLI image result did not check its error state or image recognition; neither counts as release validation. China-version results do not validate the International route. Automated checks use synthetic attachments and a fake CLI, with no live model request. The adapter combines the native stream-json image input and JSON Schema structured output formats described separately in the official CLI docs. A live image call still requires valid International CLI sign-in and access to the selected model. Not all models or the DSH upload UI flow have been verified.

## [0.1.4](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/releases/tag/v0.1.4)

- 将模型响应改为官方 CLI `--json-schema` 与 `StructuredOutput` 路线，只读取唯一最终结果记录的 `structured_output`。CLI 业务工具关闭，MCP 配置为空；DSH 继续负责工具执行。
- 严格校验 `{ text, toolCalls }` 和对象型工具参数。缺少结构结果、结构无效、CLI 报错或最终结果记录不是唯一一条时明确失败；相同内容的多条最终记录也不合并。单份计划内部的重复工具调用按原顺序保留。
- 适配器每个请求只启动一次 CLI，不会自动追加修复请求或重放已完成工具；CLI 内部最多 4 轮结构化处理。一次 CLI 调用不保证一次模型推理或固定用量，实际消耗以官方明细为准。
- 配置页和基础日志标明 `native-json-schema` 输出模式与最终记录数；保留 CLI 进程诊断、超时、取消、日志隐私和国际版独立配置/登录。
- 63 项合成自动检查通过。本版未使用国际版真实模型验证新的结构化输出路线；国内版测试不作为国际模型验证证据。

- Move model responses to the official CLI `--json-schema` and `StructuredOutput` route, consuming `structured_output` only from a unique final result record. CLI business tools stay disabled and MCP is empty; DSH continues to execute tools.
- Strictly validate `{ text, toolCalls }` and object-valued tool arguments. Missing native output, invalid structures, CLI errors or any non-unique final-record count fail explicitly; identical duplicate records are not merged. Repeated calls inside one plan remain in order.
- The adapter starts one CLI process per request and does not append a repair request or replay completed tools. The CLI may use up to four internal structured-processing rounds. One CLI invocation does not guarantee one model inference or fixed usage; official usage details are authoritative.
- Show `native-json-schema` mode and final-record count in status/diagnostics; retain process diagnostics, timeout, cancellation, log privacy and separate international configuration/sign-in.
- All 63 synthetic automated checks pass. This release did not live-test the new structured-output route with an international model; China-version tests are not evidence of international model behavior.

## [0.1.3](https://github.com/1924225725-collab/dsh-codebuddy-cli-intl/tree/v0.1.3)

- 按国内版 0.3.0 的通用修复逐项对照移植，保留国际 CLI 的 `public` 环境、International Site 登录、`codebuddy.ai` 服务入口、独立配置目录、插件 ID 与本机日志目录。
- 多个完整协议结果只有在交付文字及有序工具名称/最终参数完全一致时才去重为一份；不选择最后方案、不合并冲突，也不删除单一计划内部的重复调用。
- 文字转义恢复仅适用于完整且恰好包含 `text` 与空 `toolCalls` 的对象；不补全结构或修复工具参数。未闭合输出、冲突方案和无效工具请求继续失败。
- 兼容明确无工具的纯文字与无关完整示例；保留扫描诊断。失败时不部分交付、不自动追加模型修复请求，也不重跑已完成工具。
- 分类 CLI 空输出、401 鉴权、固定权限和限流提示；保留 DSH 机器错误码、diagnostic-id 和工具结果 `isError`。完成的 CLI 调用及时释放活动计数。
- 主动取消 `ABORTED` 不消耗已开启的一次失败回复采集。普通日志不含正文；详细样本仍需手动开启、预览并在分享前检查。
- 设置页增加中英故障处理指南。55 项合成自动检查通过；本版没有新增真实账号或模型请求验证。

This release selectively ports the region-neutral fixes compared with China 0.3.0 while retaining the international CLI's public environment, International Site sign-in, `codebuddy.ai` service route, separate profile, plugin identity and local log directory.
- Identical complete protocol results are deduplicated only when delivered text and ordered tool names/final arguments match exactly. Conflicts are never selected or merged; repeated calls inside one plan remain intact.
- Text escape recovery is limited to complete objects containing exactly `text` and empty `toolCalls`. It does not invent structure or repair tool arguments. Incomplete output, conflicting plans and invalid tools still fail.
- Support clear tool-free plain text and unrelated complete examples with scan diagnostics. Failures never partially deliver tools, request an automatic model repair or replay completed tools.
- Classify empty CLI output, 401 sign-in, fixed permission and rate-limit notices. Preserve DSH error codes, diagnostic IDs and tool-result `isError`; release completed request counts promptly.
- User-aborted `ABORTED` requests do not consume armed failure capture. Basic logs exclude reply bodies; detailed samples remain opt-in and require review before sharing.
- Add bilingual in-settings troubleshooting. All 55 synthetic automated checks pass; no new live account or model requests were made for this release.

International versioning is independent. Releases advance through 0.1.9 and then continue at 0.2.0; no 0.1.10 release will be created.

## 0.1.0

首次国际版独立发布，基于已验证的 0.1.0-alpha.1 适配器。包含官方 CLI 国际站登录与 `public` 区域调用、动态模型目录和倍率、一键配置、独立 CLI 配置目录、中英设置页、DSH 工具续接及 Token 统计。旧安装包保留在对应历史版本中。

First independent international release, prepared from the verified 0.1.0-alpha.1 adapter. Includes official CLI international sign-in and public routing, dynamic model/rate discovery, one-click setup, a separate CLI profile, bilingual settings, DSH tool continuation and token statistics. The original package remains available in its historical release.
